Main.R 

- R replication code for "Finite Sample Inference for the Maximum Score Estimand," June 2024, by Adam Rosen and Takuya Ura. On a MacBook Air (M1, 2020) with 16 GB Memory, it takes around 465.8 hours (3354 seconds times 500 iterations) for the Monte Carlo simulations and around 4.5 hours for the empirical application. To obtain the results for Monte Carlo simulations, we distributed the tasks across multiple machines. It uses the Gurobi optimizer (Gurobi Optimization, LLC). Lines 1-72 set up libraries, variables, and functions for later use.  The Monte Carlo simulations are in Lines 74-416, and the empirical application is in Lines 419-571.

results.txt 

- R display output for the computation times and the results for the empirical application. When implementing Chen and Lee in Lines 173-212 of Main.R, we follow their Gauss code. The object kern_diff_X_mat_gamma in Line 192 is computed within the loop of Lines 184-211 and the loop of Lines 191-194. It is computationally inefficient, so we compute kern_diff_X_mat_gamma out of these loops when recording the computational time for Chen and Lee.  

Horowitz.RData

- Dataset for the empirical application. 

cpp_CJN.cpp

- C++ file for implementing Cattaneo, Jansson, and Nagasawa (2020). It is used in Line 217 of Main.R. Originally downloaded from https://github.com/mdcattaneo/replication-CJN_2020_ECMA/blob/master/main_maxscore_cpp.cpp

result folder 

- Collects all the results from the Monte Carlo simulations. Lines 74-290 produce these files. 

figure folder 

- Collects all the figures from the Monte Carlo simulations. Lines 293-416 produce these files. 

