Sys.time()

rm(list = ls())

list.of.packages <- c("foreach", "doParallel", "MASS","slam","Matrix","gurobi","nloptr","Rcpp")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
for(lib_name in list.of.packages){ eval(parse(text=paste("library(",lib_name,")",sep=""))) }

sessionInfo()

n_list = c(100,250,1000)
K_list = c(2,5)

Sim_N       = 500
nV          = 500
B_size      = 500
N_gridpoint = 1e4
rndgrid     = 500
alpha       = .1
eps         = 1e-8
method_list = c("RU_500","RU_1000","CL","HSA3","HSB3","HSA2","HSB2","CJN","LR")

gurobi_params = list(OutputFlag=0,OptimalityTol=1e-5) 

color_list = c("black","red","blue","orange","grey")

ddnorm <- function(v) { -v*dnorm(v) }

V_set_creation = function(X_mat,n,K,maxVsize,b_lb,b_ub,eps){
  if (K==2) { 
    temp = t(-(2*(X_mat[,1]*X_mat[,2]>0)-1)*abs(X_mat[,1])/(eps+abs(X_mat[,2])))
    V_set = rbind(1,cbind(min(temp)-1,temp + min(abs(diff(as.vector(temp))))/2))
  } else { 
    V_set = matrix(c(1,rep(0,K-1)),ncol=1)
    for (i in 1:n) {for (j in 1:dim(V_set)[2]) {  
      if (dim(V_set)[2]>=maxVsize) { break }  
      model            = list()
      model$modelsense = 'max'
      model$obj        = c(rep(0,K),1)
      model$A          = cbind((diag((1-2*((1:i)==i))*c(2*(X_mat[1:i,]%*%V_set[,j]>0)-1), nrow = i) %*% X_mat[1:i,,drop=FALSE]),-1)
      model$lb         = c(b_lb,-Inf)
      model$ub         = c(b_ub,1)
      model$sense      = rep('>',i)
      result           = gurobi(model,params=gurobi_params)
      if (result$objval > 0) {
        V_set = cbind(V_set,result$x[1:K])
      }
    }}
  }
  return(V_set)
}

test_RU = function(b_list,Y_vec,X_mat,V_set,B_size,n,eps,alpha){
  set.seed(999) 
  Y_ast = matrix(runif(n*B_size)<.5,n,B_size)
  Y_sign = 2*cbind(Y_vec,Y_ast)-1
  XV_pos = X_mat%*%V_set>0
  XV_neg = X_mat%*%V_set<0
  Xb_pos = X_mat%*%b_list>=0
  Xb_neg = X_mat%*%b_list<=0
  mean_Xb_XV_sign = cbind(t(Xb_pos)%*%XV_neg/n,t(Xb_neg)%*%XV_pos/n)
  TestStat = matrix(NaN,1+B_size,dim(b_list)[2])
  for (b_index in 1:dim(b_list)[2]) {
    mu     = t(Y_sign)%*%cbind(diag(Xb_pos[,b_index],nrow=n)%*%XV_neg,-diag(Xb_neg[,b_index],nrow=n)%*%XV_pos)/n
    sigma2 = matrix(mean_Xb_XV_sign[b_index,],nrow=1+B_size,ncol=2*dim(V_set)[2],byrow=TRUE)-mu^2
    TestStat[,b_index] = -sqrt(n)*apply(mu/(eps+sqrt(sigma2)),1,min)
  }
  return(rbind(TestStat[1,],apply(TestStat[-1,],MARGIN=2,FUN=quantile,probs=1-alpha)))
}

for (sub_dir in c("figure","result")) {if (!file.exists(sub_dir)){ dir.create(file.path(getwd(),sub_dir)) }}

for(n in n_list){ for(K in K_list){ for(design_index in 1:8){

  beta   = c(1,1,rep(0,K-2))
  b_list = rbind(1,seq(-1,3,.1),matrix(0,K-2,length(seq(-1,3,.1))))
  mean_X = c(0,matrix(1,1,K-1))

  b_lb  = c(1,rep(-999,K-1))
  b_ub  = c(1,rep(999,K-1))

  for(method in method_list){ eval(parse(text=paste("Result_",method," = matrix(NaN,Sim_N,dim(b_list)[2])",sep=""))) }

  for(random_index in 1:Sim_N){
    set.seed(random_index)
    start_time = Sys.time()

    X_mat = matrix(mean_X,n,K,byrow=TRUE)+matrix(rnorm(n*K),n,K)
    if (design_index==1|design_index==5) {
      U_vec = rlogis(n,location=0,scale=sqrt(3/pi^2))
    } else if (design_index==2|design_index==6) {
      U_vec = runif(n,min=-sqrt(12)/2,max=sqrt(12)/2)
    } else if (design_index==3|design_index==7) {
      U_vec = rt(n,df=3)/sqrt(3)
    } else {
      U_vec = 0.25*(1+2*apply(X_mat,1,sum)^2+apply(X_mat,1,sum)^4)*rlogis(n,location=0,scale=sqrt(3/pi^2))
    }
    
    if (design_index>4){         
      U_vec[U_vec>0] = 0*U_vec[U_vec>0]
    }
    
    Y_vec = as.vector((X_mat%*%beta)>=U_vec)

    XX_mat = (matrix(1,1,K-1)%x%X_mat[,-1,drop=FALSE])*(X_mat[,-1,drop=FALSE]%x%matrix(1,1,K-1))

    if (design_index<=4|K==2) {
      #### SMS
  
      for(inv_undersmooth_factor in 2:3){
        undersmooth_factor = 1/inv_undersmooth_factor
  
        kernel_0 = function(V){ (abs(V)<5)*(0.5+(105/64)*(V/5-(5/3)*((V/5)^3)+(7/5)*((V/5)^5)-(3/7)*((V/5)^7)))+(V>5) }
        kernel_1 = function(V){ (abs(V)<5)*(105/64)*(1/5-(V/5)^2+(7/5)*((V/5)^4)-(3/5)*((V/5)^6)) }
        kernel_2 = function(V){ (abs(V)<5)*(105/64)*(-(2/5)*(V/5)+(28/25)*((V/5)^3)-(18/25)*((V/5)^5)) }
  
        construct_SMS = function(bandwidth,Y_use,X_use){
          objfxn    <- function(theta) { -t(2*Y_use-1)%*%kernel_0(X_use%*%c(1,theta)/bandwidth)/n }
          objfxn_d1 <- function(theta) { -t((2*Y_use-1)*kernel_1(X_use%*%c(1,theta)/bandwidth))%*%X_use[,-1]/(n*bandwidth) }
          return(nloptr(x0=beta[-1],eval_f=objfxn,eval_grad_f=objfxn_d1,opts=list("algorithm"="NLOPT_LD_TNEWTON"),lb=rep(-1,K-1),ub=rep(3,K-1))$solution)
        }
  
        construct_DN = function(bandwidth,Y_use,X_use,XX_use,theta){ matrix(t(kernel_1(X_use%*%c(1,theta)/bandwidth)^2)%*%XX_use,K-1,K-1)/(n*bandwidth) }
        construct_QN = function(bandwidth,Y_use,X_use,XX_use,theta){ matrix(t((2*Y_use-1)*kernel_2(X_use%*%c(1,theta)/bandwidth))%*%XX_use,K-1,K-1)/(n*(bandwidth^2)) }
  
        # Computate lambda_N in Horowitz (1992, Section 2d)
        sms_est = construct_SMS(n^(-1/(2*4+1)),Y_vec,X_mat)
        bandwidth = n^(-0.1/(2*4+1))
        D_N <- construct_DN(bandwidth,Y_vec,X_mat,XX_mat,sms_est)
        Q_N <- construct_QN(bandwidth,Y_vec,X_mat,XX_mat,sms_est)
        A_N <- (bandwidth^(-4))*t(X_mat[,-1,drop=FALSE])%*%((2*Y_vec-1)*kernel_1(X_mat%*%c(1,sms_est)/bandwidth))/(n*bandwidth)
        lambda_N = sum(diag(matrix(ginv(Q_N%*%Q_N)%*%D_N,nrow=K-1,ncol=K-1)))/as.numeric(2*4*t(A_N)%*%ginv(Q_N)%*%ginv(Q_N)%*%A_N)
  
        # Computate SMS and chisq test stat
        bandwidth = undersmooth_factor*(lambda_N/n)^(1/(2*4+1))
        sms_est = construct_SMS(bandwidth,Y_vec,X_mat)
        D_N <- construct_DN(bandwidth,Y_vec,X_mat,XX_mat,sms_est)
        Q_N <- construct_QN(bandwidth,Y_vec,X_mat,XX_mat,sms_est)
        W_stat = rep(NaN,dim(b_list)[2])
        for(b_index in 1:dim(b_list)[2]){
          W_stat[b_index] = (n*bandwidth)*t(sms_est-b_list[-1,b_index])%*%Q_N%*%ginv(D_N)%*%Q_N%*%(sms_est-b_list[-1,b_index])
        }
        eval(parse(text=paste("Result_HSA",inv_undersmooth_factor,"[",random_index,",] = W_stat<=qchisq(1-alpha,df=K-1)",sep="")))
  
        #Compute chisq test stat for bootstrapped samples
        W_stat_boot = rep(NaN,B_size)
        for( boot_index in 1:B_size){
          boot.idx <- sample(n, replace = T)
          sms_est_boot = construct_SMS(bandwidth,Y_vec[boot.idx],X_mat[boot.idx,])
          D_N <- construct_DN(bandwidth,Y_vec[boot.idx],X_mat[boot.idx,],XX_mat[boot.idx,],sms_est_boot)
          Q_N <- construct_QN(bandwidth,Y_vec[boot.idx],X_mat[boot.idx,],XX_mat[boot.idx,],sms_est_boot)
          W_stat_boot[boot_index] = (n*bandwidth)*t(sms_est_boot-sms_est)%*%Q_N%*%ginv(D_N)%*%Q_N%*%(sms_est_boot-sms_est)
        }
        eval(parse(text=paste("Result_HSB",inv_undersmooth_factor,"[",random_index,",] = W_stat<=quantile(W_stat_boot,1-alpha)",sep="")))
      }
      #### SMS
  
      #### RU
      V_set_double = V_set_creation(X_mat,n,K,2*nV,b_lb,b_ub,eps)
      temp  = test_RU(b_list,Y_vec,X_mat,V_set_double[,1:min(nV,dim(V_set_double)[2])],B_size,n,eps,alpha)
      Result_RU_500[random_index,]  = (temp[1,]<=temp[2,])
      #### RU
    }

    if (design_index<=4) {
      #### RU for doubled V
      temp = test_RU(b_list,Y_vec,X_mat,V_set_double,B_size,n,eps,alpha)
      Result_RU_1000[random_index,] = temp[1,]<=temp[2,]
      #### RU for doubled V


      #### CL
      tuning  = 0.1/log(n)
      u       = matrix(rnorm(n*B_size),n,B_size)
      gamma_p = matrix(beta,K,rndgrid,byrow=FALSE)+rbind(0,matrix(2*runif((K-1)*rndgrid)-1,K-1,rndgrid))
      x       = matrix(mean_X,rndgrid,K,byrow=TRUE)+matrix(rnorm(rndgrid*K),rndgrid,K)
      wsize   = 3.05/(n^(1/5))
      kern    = function(v) { (15/16)*((1-v^2)^2)*(abs(v)<= 1) }

      hsize_gamma  = eps+wsize*apply(X_mat%*%gamma_p,2,sd)
      kern_values1 = kern((matrix(diag(x%*%gamma_p),n,rndgrid,byrow=TRUE)-X_mat%*%gamma_p)/matrix(hsize_gamma,n,rndgrid,byrow=TRUE))

      for(b_index in 1:dim(b_list)[2]){
        b = b_list[,b_index]

        hsize_xb  = eps+wsize*sd(X_mat%*%b)

        kern_diff_X_mat_b = kern((matrix(X_mat%*%b,n,n,byrow=TRUE)-matrix(X_mat%*%b,n,n,byrow=FALSE))/hsize_xb)
        e_hat = matrix(NaN,n,rndgrid)
        for(k1 in 1:rndgrid){
          kern_diff_X_mat_gamma = kern((matrix(X_mat%*%gamma_p[,k1],n,n,byrow=TRUE)-matrix(X_mat%*%gamma_p[,k1],n,n,byrow=FALSE))/hsize_gamma[k1])
          e_hat[,k1] = ((kern_diff_X_mat_b*kern_diff_X_mat_gamma)%*%matrix(Y_vec,n,1))/(eps+(kern_diff_X_mat_b*kern_diff_X_mat_gamma)%*%matrix(1,n,1))# e_hat[i][k1] = E_hat(Y|X[i]'b,X[i]'r[k1])
        }
        
        kern_values   = kern_values1*kern((matrix(x%*%b,n,rndgrid,byrow=TRUE)-matrix(X_mat%*%b,n,rndgrid,byrow=FALSE))/hsize_xb)

        sigma_hat = eps+sqrt(matrix((X_mat%*%b)^2,1,n,byrow=FALSE)%*%((matrix(Y_vec,n,rndgrid,byrow=FALSE)-e_hat)*kern_values)^2)
        std_m_hat = (matrix((X_mat%*%b)*(Y_vec-0.5),1,n)%*%kern_values)/sigma_hat
        w_hat     = (matrix(X_mat%*%b,n,rndgrid,byrow=FALSE)*(matrix(Y_vec,n,rndgrid,byrow=FALSE)-e_hat)*kern_values)/matrix(sigma_hat,n,rndgrid,byrow=TRUE)
        select    = std_m_hat<=-2*quantile(apply(t(w_hat)%*%u,2,min),tuning)

        if (sum(select)>1){
          cv = quantile(apply(t(w_hat[,select])%*%u,2,min),alpha)
        } else if (sum(select)==1) {
          cv = quantile(t(w_hat[,select])%*%u,alpha)
        } else {
          cv = Inf
        }
        Result_CL[random_index,b_index] = min(std_m_hat)>=cv
      }
      #### CL

      if (K==2){
        #### CJN

        sourceCpp("cpp_CJN.cpp")

        B <- 2000
        grids <- c( seq(-1,0,0.01), seq(0.002,2,0.002), seq(2.01,3,0.01) )

        bhat <- maxscore(Y_vec, X_mat[,1], X_mat[,2], grids)

        ll <- function(par){
          z <- X_mat[,1] + X_mat[,2]*par[1]
          v <- par[2] + par[3]*z + par[4]*z^2 + par[5]*z^3 + par[6]*z^4
          t1 <- Y_vec*log(pnorm(z/v) )
          t2 <- (1-Y_vec)*log(1-pnorm(z/v))
          t1[is.nan(t1)] <- -Inf
          t2[is.nan(t2)] <- -Inf
          min( -mean( t1 + t2 ), 1e3)
        }

        para <- optim( c(1,1,rep(0,4)), ll)$par
        mu1 <- mean(X_mat[,1])
        sigma1 <- sd(X_mat[,1])

        B.ker <- mean( X_mat[,2]^2*((dnorm(0)/para[2])*( (X_mat[,2]*para[1] + mu1)^2/sigma1^2 - 1)/sigma1^3*dnorm( (X_mat[,2]*para[1] + mu1)/sigma1 ))+ X_mat[,2]^2*(1/3*(dnorm(0)*(2*para[4]/para[2]^2 - 2*para[3]^2/para[2]^3) - dnorm(0)/para[2]^3)*dnorm( (X_mat[,2]*para[1] + mu1)/sigma1 )/sigma1))*(-3)

        plugin.ROT.bw <- (3*mean( X_mat[,2]^2*dnorm( (X_mat[,2]*para[1] + mu1)/sigma1 )/sigma1 )*0.1410474/4/B.ker^2)^(1/7)*n^(-1/7)

        H.ms.ROT <- mean( (2*Y_vec - 1)*ddnorm( (X_mat[,1] + X_mat[,2]*bhat)/plugin.ROT.bw )/plugin.ROT.bw^2*X_mat[,2]^2 )

        plugin.ROT <- rep(NA,B)
        for (b in 1:B){
          boot.idx <- sample(n, replace = T)
          plugin.ROT[b] <- boot_ms(Y_vec, X_mat[,1], X_mat[,2], Y_vec[boot.idx], X_mat[boot.idx,1], X_mat[boot.idx,2], grids,H.ms.ROT, bhat)
        }

        temp = 2*bhat-quantile(plugin.ROT,c(1-alpha/2,alpha/2))
        Result_CJN[random_index,] = (temp[1]<b_list[2,]) & (b_list[2,]<temp[2])
        #### CJN
      }

      if (K==2&n==100) {
        #### LR

        Y_ast  = matrix(runif(n*B_size)<.5,n,B_size)

        score_max_value = rep(NaN,1+B_size)
        for(score_max_index in 1:(1+B_size)){

          C_large = K*max(abs(c(b_lb,b_ub)))*max(abs(X_mat))

          model            = list()
          model$vtype      = c(rep('C',K),rep('B',n))
          model$obj        = c(rep(0,K),rep(1/n,n))
          model$modelsense = 'max'
          model$A          = cbind((1-2*cbind(Y_vec,Y_ast)[,score_max_index])*X_mat,C_large*diag(n))
          model$rhs        = rep(C_large,n)
          model$lb         = c(b_lb,rep(0,n))
          model$ub         = c(b_ub,rep(1,n))

          score_max_value[score_max_index] = gurobi(model,params=gurobi_params)$objval
        }

        TestStat = matrix(NaN,1+B_size,dim(b_list)[2])
        for(b_index in 1:dim(b_list)[2]){
          score_value = apply((diag(as.vector(X_mat%*%b_list[,b_index]))%*%(2*cbind(Y_vec,Y_ast)-1))>=0,2,mean)
          TestStat[,b_index] = score_max_value-score_value
        }
        Result_LR[random_index,]  = TestStat[1,]<=apply(TestStat[-1,],MARGIN=2,FUN=quantile,probs=1-alpha)
        #### LR
      }
    }  
    end_time = Sys.time()
    print(c(n,K,design_index,random_index,difftime(end_time,start_time,units="secs")))
  }
  save(b_list,Result_RU_500,Result_RU_1000,Result_LR,Result_CL,Result_HSA2,Result_HSB2,Result_HSA3,Result_HSB3,Result_CJN,file=paste("result/",n,"_",K,"_",design_index,".RData",sep=""))
}}}


for(n in n_list){ for(K in K_list){ 
  
  beta   = c(1,1,rep(0,K-2))
  b_list = rbind(1,seq(-1,3,.1),matrix(0,K-2,length(seq(-1,3,.1))))

  for(method in method_list){
    eval(parse(text=paste("mean_",method," = matrix(NaN,8,dim(b_list)[2])",sep="")))
    for (design_index in 1:8) {
      load(paste("result/",n,"_",K,"_",design_index,".RData",sep=""))
      eval(parse(text=paste("mean_",method,"[design_index,] = apply(Result_",method,",2,mean)",sep="")))
    }
  }

  pdf(file=paste("figure/MC",n,"_",K,"_all.pdf",sep=""))
  par(mfrow=c(2,2))
  for (design_index in 1:4) {
    plot(b_list[2,],mean_RU_500[design_index,], col=color_list[1], type = "l", ylim=c(0,1), lty=1, frame = FALSE, ann=FALSE)
    axis(2, at=c(.2,.4,.6,.8),labels=c(.2,.4,.6,.8))
    abline(h=1-alpha,lty=3)
    abline(v=beta[2],lty=3)
    lines(b_list[2,],mean_CL[design_index,],lty=2, col=color_list[2])
    lines(b_list[2,],mean_HSA2[design_index,],lty=3, col=color_list[3])
    lines(b_list[2,],mean_HSB2[design_index,],lty=4, col=color_list[4])
    if (K==2) {
      lines(b_list[2,],mean_CJN[design_index,],   lty=5, col=color_list[5])
      legend("bottomright", legend=c("RU", "CL","HSA", "HSB", "CJN"),col=color_list[1:5], lty=1:5, cex=0.8,bg='white')
    } else {
      legend("bottomright", legend=c("RU", "CL","HSA", "HSB"),col=color_list[1:4], lty=1:4, cex=0.8,bg='white')
    }
    title(main=paste("Design",design_index),xlab="b2",ylab="Coverage Frequency")
  }
  dev.off()

  pdf(file=paste("figure/MC_compareV_",n,"_",K,".pdf",sep=""))
  par(mfrow=c(2,2))
  for (design_index in 1:4) {
    plot(b_list[2,],mean_RU_500[design_index,], col=color_list[1], type = "l", ylim=c(0,1), lty=1, frame = FALSE, ann=FALSE)
    axis(2, at=c(.2,.4,.6,.8),labels=c(.2,.4,.6,.8))
    abline(h=1-alpha,lty=3)
    abline(v=beta[2],lty=3)
    lines(b_list[2,],mean_RU_1000[design_index,],lty=2, col=color_list[2])
    legend("bottomright", legend=c("RU with |V|=500", "RU with |V|=1000"),col=color_list[1:2], lty=1:2, cex=0.8,bg='white')
    title(main=paste("Design",design_index),xlab="b2",ylab="Coverage Frequency")
  }
  dev.off()

  print(rbind(b_list[2,],mean_RU_1000-mean_RU_500))

  pdf(file=paste("figure/MC_compareSMS_",n,"_",K,".pdf",sep=""))
  par(mfrow=c(2,2))
  for (design_index in 1:4) {
    plot(b_list[2,],mean_HSA3[design_index,], col=color_list[1], type = "l", ylim=c(0,1), lty=1, frame = FALSE, ann=FALSE)
    axis(2, at=c(.2,.4,.6,.8),labels=c(.2,.4,.6,.8))
    abline(h=1-alpha,lty=3)
    abline(v=beta[2],lty=3)
    lines(b_list[2,],mean_HSB3[design_index,],   lty=2, col=color_list[2])
    lines(b_list[2,],mean_HSA2[design_index,],   lty=3, col=color_list[3])
    lines(b_list[2,],mean_HSB2[design_index,],   lty=4, col=color_list[4])
    legend("bottomright", legend=c("HSA with 1/3","HSB with 1/3","HSA with 1/2","HSB with 1/2"),col=color_list[1:4], lty=1:4, cex=0.8,bg='white')
    title(main=paste("Design",design_index),xlab="b2",ylab="Coverage Frequency")
  }
  dev.off()

  pdf(file=paste("figure/MC",n,"_",K,"_withLR.pdf",sep=""))
  par(mfrow=c(2,2))
  for (design_index in 1:4) {
    plot(b_list[2,],mean_RU_500[design_index,], col=color_list[1], type = "l", ylim=c(0,1), lty=1, frame = FALSE, ann=FALSE)
    axis(2, at=c(.2,.4,.6,.8),labels=c(.2,.4,.6,.8))
    lines(b_list[2,],mean_LR[design_index,],lty=2, col=color_list[2])
    abline(h=1-alpha,lty=3)
    abline(v=beta[2],lty=3)
    legend("bottomright", legend=c("RU","LR Test Stat"),col=color_list[1:2], lty=1:2, cex=0.8,bg='white')
    title(main=paste("Design",design_index),xlab="b2",ylab="Coverage Frequency")
  }
  dev.off()


  pdf(file=paste("figure/MC_zeromass",n,"_",K,"_all.pdf",sep=""))
  par(mfrow=c(2,2))
  for (design_index in 5:8) {
    plot(b_list[2,],mean_RU_500[design_index,], col=color_list[1], type = "l", ylim=c(0,1), lty=1, frame = FALSE, ann=FALSE)
    axis(2, at=c(.2,.4,.6,.8),labels=c(.2,.4,.6,.8))
    abline(h=1-alpha,lty=3)
    abline(v=beta[2],lty=3)
    lines(b_list[2,],mean_HSA2[design_index,],lty=2, col=color_list[2])
    lines(b_list[2,],mean_HSB2[design_index,],lty=3, col=color_list[3])
    if (K==2) {
      legend("bottomright", legend=c("RU","HSA", "HSB"),col=color_list[1:3], lty=1:3, cex=0.8,bg='white')
    }
    title(main=paste("Design",design_index),xlab="b2",ylab="Coverage Frequency")
  }
  dev.off()
  
  pdf(file=paste("figure/MC_zeromass_compareSMS_",n,"_",K,".pdf",sep=""))
  par(mfrow=c(2,2))
  for (design_index in 5:8) {
    plot(b_list[2,],mean_HSA3[design_index,], col=color_list[1], type = "l", ylim=c(0,1), lty=1, frame = FALSE, ann=FALSE)
    axis(2, at=c(.2,.4,.6,.8),labels=c(.2,.4,.6,.8))
    abline(h=1-alpha,lty=3)
    abline(v=beta[2],lty=3)
    lines(b_list[2,],mean_HSB3[design_index,],   lty=2, col=color_list[2])
    lines(b_list[2,],mean_HSA2[design_index,],   lty=3, col=color_list[3])
    lines(b_list[2,],mean_HSB2[design_index,],   lty=4, col=color_list[4])
    legend("bottomright", legend=c("HSA with 1/3","HSB with 1/3","HSA with 1/2","HSB with 1/2"),col=color_list[1:4], lty=1:4, cex=0.8,bg='white')
    title(main=paste("Design",design_index),xlab="b2",ylab="Coverage Frequency")
  }
  dev.off()
     
}}

n      = 1e5
K      = 2
beta   = c(1,1,rep(0,K-2))
temp   = seq(-1,3,.01)
b_list = rbind(1,temp,matrix(0,K-2,length(temp)))

X_mat = cbind(0,matrix(1,n,K-1))+matrix(rnorm(n*K),n,K)

pdf(file="figure/MC_X.pdf")
plot(b_list[2,],apply(matrix(X_mat%*%beta,n,dim(b_list)[2])*(X_mat%*%b_list)<0,2,mean), col="black", type = "l", ylim=c(0,.8), lty=1, frame = FALSE, ann=FALSE)
abline(h=0,lty=3)
abline(v=beta[2],lty=3)
title(xlab="b2",ylab="Probability of Sign Change")
dev.off()


doParallel::registerDoParallel( parallel::makeCluster(6))

tab1 = c()
tab2 = c()
tab3 = c()
tab4 = c()
tab5 = c()

for(car_number in 0:2){
  
  set.seed(1111) 

  print(car_number)
  load("Horowitz.RData")
  selection = (X_mat[,2]==car_number)
  tab1 = cbind(tab1,rbind(c(mean(Y_vec[selection]),sd(Y_vec[selection])),c(mean(X_mat[selection,1]),sd(X_mat[selection,1])),c(mean(X_mat[selection,3]),sd(X_mat[selection,3])),c(mean(X_mat[selection,4]),sd(X_mat[selection,4]))))

  X_mat     = cbind(1,scale(X_mat,center=TRUE,scale=FALSE))[selection,-3]
  Y_vec     = Y_vec[selection]

  n = length(Y_vec)
  K = dim(X_mat)[2]

  b_lb  = c(2*(mean(Y_vec)>.5)-1,rep(-10,dim(X_mat)[2]-1))
  b_ub  = c(2*(mean(Y_vec)>.5)-1,rep(10,dim(X_mat)[2]-1))

  C_large = K*max(abs(c(b_lb,b_ub)))*max(abs(X_mat))

  V_set = V_set_creation(X_mat,n,K,nV,b_lb,b_ub,eps)

  print("the maximum score estimators")
  model       = list()
  model$vtype = c(rep('C',K),rep('B',n))
  model$lb    = c(b_lb,rep(0,n))
  model$ub    = c(b_ub,rep(1,n))

  model$rhs        = rep(C_large,n)
  model$A          = cbind((1-2*Y_vec)*X_mat,C_large*diag(n))
  model$obj        = c(rep(0,K),rep(1/n,n))
  model$modelsense = 'max'

  model$rhs   = c(model$rhs,gurobi(model,params=gurobi_params)$objval)
  model$A     = rbind(model$A,model$obj)
  model$sense = c(rep('<',n),'>')

  max_score_set = matrix(foreach(component_index=1:(2*K), .combine='c',.packages=list.of.packages) %dopar% {
    if(component_index<=K){
      model$modelsense = 'min'
    } else {
      model$modelsense = 'max'
      component_index = component_index-K
    }
    if (component_index==1){
      b_lb[1]
    } else {
      model$obj = as.numeric(component_index==(1:(K+n)))
      gurobi(model,params=gurobi_params)$objval
    }
  },K,2)
  print(max_score_set)
  tab3 = cbind(tab3,max_score_set)


  cv_bar = max(test_RU(V_set,Y_vec,X_mat,V_set,B_size,n,eps,alpha)[2,])

  model       = list()
  model$lb    = c(b_lb,rep(0,2*n+2*dim(V_set)[2]))
  model$ub    = c(b_ub,rep(1,2*n),sqrt(rep(1/n,n)%*%((X_mat%*%V_set)<0)),sqrt(rep(1/n,n)%*%((X_mat%*%V_set)>0)))
  model$vtype = c(rep('C',K),rep('B',2*n),rep('C',2*dim(V_set)[2]))
  model$A     = as(rbind(
    cbind(X_mat,-C_large*diag(1,nrow=n),matrix(0,n,n+2*dim(V_set)[2])),
    cbind(-X_mat,diag(0,nrow=n),-C_large*diag(1,nrow=n),matrix(0,n,2*dim(V_set)[2])),
    cbind(matrix(0,n,K),diag(1,nrow=n),diag(1,nrow=n),matrix(0,n,2*dim(V_set)[2])),
    cbind(matrix(0,dim(V_set)[2],K),-sqrt(n)*t((X_mat%*%V_set)<0)%*%diag(2*Y_vec-1)/n,matrix(0,dim(V_set)[2],n),-cv_bar*diag(1,nrow=dim(V_set)[2]),diag(0,nrow=dim(V_set)[2])),
    cbind(matrix(0,dim(V_set)[2],K+n),-sqrt(n)*t((X_mat%*%V_set)>0)%*%diag(1-2*Y_vec)/n,diag(0,nrow=dim(V_set)[2]),-cv_bar*diag(1,nrow=dim(V_set)[2]))
  ),"sparseMatrix")
  model$rhs   = c(rep(0,2*n),rep(1,n),rep(0,2*dim(V_set)[2]))
  model$sense = c(rep('<',2*n),rep('=',n),rep('<',2*dim(V_set)[2]))
  model$quadcon = list()
  for(quadcon_index in 1:(2*dim(V_set)[2])){
    model$quadcon[[quadcon_index]] = list()
    model$quadcon[[quadcon_index]]$Qc = sparseMatrix(i=K+2*n+quadcon_index,j=K+2*n+quadcon_index,x=1,dims = rep(K+2*n+2*dim(V_set)[2],2),symmetric=TRUE)
    if (quadcon_index<=dim(V_set)[2]) {
      temp = ((X_mat%*%V_set[,quadcon_index])<0)*(2*Y_vec-1)/n
      model$quadcon[[quadcon_index]]$Qc[K+(1:n),K+(1:n)] = matrix(temp,n,1)%*%matrix(temp,1,n)
      model$quadcon[[quadcon_index]]$q  = sparseVector(x=as.numeric(-((X_mat%*%V_set[,quadcon_index])<0)/n),i=(K+(1:n)),length=K+2*n+2*dim(V_set)[2])
    } else {
      temp = ((X_mat%*%V_set[,quadcon_index-dim(V_set)[2]])>0)*(1-2*Y_vec)/n
      model$quadcon[[quadcon_index]]$Qc[K+n+(1:n),K+n+(1:n)] = matrix(temp,n,1)%*%matrix(temp,1,n)
      model$quadcon[[quadcon_index]]$q  = sparseVector(x=as.numeric(-((X_mat%*%V_set[,quadcon_index-dim(V_set)[2]])>0)/n),i=(K+n+(1:n)),length=K+2*n+2*dim(V_set)[2])
    }
  }

  start_time = Sys.time()
  CI_QP = matrix(foreach(component_index=1:(2*K), .combine='c',.packages=list.of.packages) %dopar% {
    if(component_index<=K){
      model$modelsense = 'min'
    } else {
      model$modelsense = 'max'
      component_index = component_index-K
    }
    if (component_index==1){
      b_lb[1]
    } else {
      model$obj = as.numeric(component_index==(1:(K+2*n+2*dim(V_set)[2])))
      gurobi(model,params=gurobi_params)$objval
    }
  },K,2)
  print("mixed integer CI")
  print(CI_QP)
  tab4 = cbind(tab4,CI_QP)
  end_time = Sys.time()
  print(difftime(end_time,start_time,units="secs"))

  start_time = Sys.time()
  b_list     = cbind(0,matrix((CI_QP[,1]+CI_QP[,2])/2,K,N_gridpoint)+diag(CI_QP[,2]-CI_QP[,1],nrow=K)%*%(matrix(runif(K*N_gridpoint),K,N_gridpoint)-1/2))
  Result_RU  = test_RU(b_list,Y_vec,X_mat,V_set,B_size,n,eps,alpha)
  print("significance test")
  tab2 = cbind(tab2,Result_RU[,1])
  print(Result_RU[,1])
  
  Result_RU = Result_RU[,-1]
  b_list = b_list[,-1]
  temp = matrix(NaN,K,2)
  temp[1,] = c(b_lb[1],b_ub[1])
  for (component_index in 2:K) {
    temp[component_index,] = quantile(b_list[component_index,Result_RU[1,]<=Result_RU[2,]],c(0,1))
  }
  print("test inversion CI")
  print(temp) 
  tab5 = cbind(tab5,temp)
  end_time   = Sys.time()
  print(difftime(end_time,start_time,units="secs"))
  
  start_time = Sys.time()
  double_CI_QP = cbind(pmax((CI_QP[,1]+CI_QP[,2])/2-(CI_QP[,2]-CI_QP[,1]),b_lb),pmin((CI_QP[,1]+CI_QP[,2])/2+(CI_QP[,2]-CI_QP[,1]),b_ub))
  b_list  = matrix((double_CI_QP[,1]+double_CI_QP[,2])/2,K,N_gridpoint)+diag(double_CI_QP[,2]-double_CI_QP[,1],nrow=K)%*%(matrix(runif(K*N_gridpoint),K,N_gridpoint)-1/2)
  b_list  = b_list[,apply((b_list<CI_QP[,1])|(CI_QP[,2]<b_list),MARGIN=2,FUN=any)]
  Result_RU  = test_RU(b_list,Y_vec,X_mat,V_set,B_size,n,eps,alpha)
  print("Is the proposed CI not larger than the mixed integer one?")
  print(all(Result_RU[1,]>Result_RU[2,]))
  end_time   = Sys.time()
  print(difftime(end_time,start_time,units="secs"))
  
}

print(tab1)
print(tab2)
print(tab3)
print(tab4)
print(tab5)

Sys.time()